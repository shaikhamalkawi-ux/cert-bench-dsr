CERT-Bench — Anonymous Reproducibility Package

This package accompanies the double-anonymized ESWA submission. It contains machine-readable summaries for the three benchmark systems plus the Tetouan operational secondary analysis. It contains no author name, affiliation, email, repository username, or Git history.

Benchmark summaries
- benchmark_evidence_states.csv
- benchmark_primary_results.csv
- benchmark_verification_summary.csv

Tetouan operational calculations
- published Table 3/8 transcriptions
- one-zone proportional-rescaling diagnostic
- same-matrix pipeline/family-switch diagnostic
- source-rounding vertices
- deterministic reproduction script and PASS log

Scientific boundary
The benchmark results are fixed-score decision-stability calculations under the evidence states declared in the manuscript. The Tetouan analysis is a retrospective secondary analysis of published real-SCADA forecasting results; it does not retrain models or claim field deployment. Third-party raw benchmark artifacts are not redistributed where redistribution status is unclear.
