#!/usr/bin/env python3
"""Reproduce the CERT-Bench ESWA Tetouan sensitivity diagnostics.

This is deterministic secondary analysis of published table values.
No forecasting model is retrained and no deployment outcome is inferred.
"""
from pathlib import Path
import itertools, math
import numpy as np
import pandas as pd
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
full=pd.read_csv(HERE/"tetouan_published_table8_hourly_mape.csv")
mw=pd.read_csv(HERE/"tetouan_published_table3_mean_loads_and_weights.csv")
family=pd.read_csv(HERE/"tetouan_model_family_envelope.csv")
w0=mw["observed_load_share"].to_numpy(float)

def pairwise_radius(i,j,Z,w):
    D=len(w); c=np.r_[np.zeros(D),0.5*np.ones(D)]
    A=[]; b=[]
    for d in range(D):
        row=np.zeros(2*D); row[d]=1; row[D+d]=-1; A.append(row); b.append(w[d])
        row=np.zeros(2*D); row[d]=-1; row[D+d]=-1; A.append(row); b.append(-w[d])
    row=np.zeros(2*D); row[:D]=Z[:,j]-Z[:,i]; A.append(row); b.append(0.0)
    Aeq=np.zeros((1,2*D)); Aeq[0,:D]=1.0
    res=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(b),
                A_eq=Aeq,b_eq=[1.0],
                bounds=[(0,None)]*(2*D),method="highs")
    return (float(res.fun),res.x[:D]) if res.success else (math.inf,None)

def global_radius(m,Z,w):
    D,M=Z.shape; c=np.r_[np.zeros(D),0.5*np.ones(D)]
    A=[]; b=[]
    for d in range(D):
        row=np.zeros(2*D); row[d]=1; row[D+d]=-1; A.append(row); b.append(w[d])
        row=np.zeros(2*D); row[d]=-1; row[D+d]=-1; A.append(row); b.append(-w[d])
    for ell in range(M):
        if ell==m: continue
        row=np.zeros(2*D); row[:D]=Z[:,m]-Z[:,ell]; A.append(row); b.append(0.0)
    Aeq=np.zeros((1,2*D)); Aeq[0,:D]=1.0
    res=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(b),
                A_eq=Aeq,b_eq=[1.0],
                bounds=[(0,None)]*(2*D),method="highs")
    return (float(res.fun),res.x[:D]) if res.success else (math.inf,None)

# Model-family primary
names=family["model_family"].tolist()
Z=family[["Quads_MAPE","Smir_MAPE","Boussafou_MAPE"]].to_numpy(float).T
rf=names.index("RF"); ts=names.index("TSMixer")
r,w=pairwise_radius(rf,ts,Z,w0)
gr,gw=global_radius(ts,Z,w0)
assert abs(r-0.17428890078222187)<1e-12
assert abs(gr-r)<1e-12

# One-zone proportional-rescaling path
g=Z[:,ts]-Z[:,rf]
def path(k,x):
    out=w0.copy(); out[k]=x
    for d in range(3):
        if d!=k: out[d]=w0[d]*(1-x)/(1-w0[k])
    return out
vals=[]
for k in range(3):
    a=path(k,0)@g; b=path(k,1)@g-a
    x=-a/b
    if 0<=x<=1:
        wp=path(k,x)
        vals.append((0.5*np.abs(wp-w0).sum(),k,x))
vals.sort()
assert abs(vals[0][0]-0.2268976556)<1e-9
assert vals[0][1]==1  # Smir

# 18-pipeline matrix
pipe_names=[f"{x.model_family}-{x.preprocessing}" for _,x in full.iterrows()]
Zp=full[["Quads_MAPE","Smir_MAPE","Boussafou_MAPE"]].to_numpy(float).T
scores=w0@Zp
winner=int(np.argmin(scores))
assert pipe_names[winner]=="RF-MaxAbs"
prs=[]; nonrf=[]
for j,n in enumerate(pipe_names):
    if j==winner: continue
    pr,_=pairwise_radius(winner,j,Zp,w0)
    prs.append((pr,n))
    if not n.startswith("RF-"):
        gg,_=global_radius(j,Zp,w0)
        nonrf.append((gg,n))
prs.sort(); nonrf.sort()
assert prs[0][1]=="RF-Standard"
assert abs(prs[0][0]-0.0212536285)<1e-9
assert nonrf[0][1]=="TSMixer-MinMax"
assert abs(nonrf[0][0]-0.2069682551)<1e-9

# Published rounding sensitivity: displayed MAPE rounded to nearest 0.01.
ds=[]
for eps in itertools.product([-0.01,0.01], repeat=3):
    gg=g+np.array(eps)
    h=w0@gg
    ds.append(h/(gg.max()-gg.min()))
assert abs(min(ds)-0.1670946562)<1e-9
assert abs(max(ds)-0.1814831454)<1e-9

print("PASS")
print("unrestricted_DSR",r)
print("one_zone_path_DSR",vals[0][0])
print("one_zone_path_zone","Smir")
print("nearest_pipeline_boundary",prs[0])
print("nearest_nonRF_global",nonrf[0])
print("rounding_band",min(ds),max(ds))
